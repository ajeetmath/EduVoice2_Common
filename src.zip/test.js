'TopicIntent': function () {
    console.log("Starting mainStateHandler:TopicIntent");
    this.attributes['IntentState'] = "TopicIntent";

    this.attributes["challengeLevelInd"] = '';
    var SelectedTopic = "";

    var updatedIntent = this.event.request.intent;
    var slotToElicit;

  //  if (this.attributes['userName']) {

      console.log("mainStateHandlers:TopicIntent start ")
      this.attributes["Topic"] = this.event.request.intent.slots.Topic.value;
      var topic = this.attributes["Topic"]
      console.log("User requested topic  -> " + topic);

      var availableChallengeLevel;
      var topicFound = false;
      var topicName = "";
      var similarity = ""
      var maxSimilarity = "";
      var availableChallengeLevel = "";

      var ar = [];
      var events = JSON.stringify(this.event);
      for (var i = 0; i < events.length; i++) {
        ar += events[i];
      }
      console.log("TopicIntent request ->" + ar);


      pointerToThis = this;
      async.waterfall([
          function (callback) {

            var db_access = {
              host: dbconfig.db.host,
              user: dbconfig.db.username,
              password: dbconfig.db.password,
              database: dbconfig.db.dbname,
              port: dbconfig.db.port
            };

            console.log(' connection:TopicIntent calling DB');
            var conn = mysql.createConnection(db_access);
            conn.connect();

            //callback(conn, callback)
            var readTopicQuery = "call SP_testTopics_alexa ('" + pointerToThis.attributes['UserId'] + "')";

            //var readTopicQuery = "select count(challenge) as num, topic.topicId, topic.name as name, challenge from EduVoiceDB.question Inner Join EduVoiceDB.topic on topic.topicId = question.topicId and topic.publish = '1' inner join EduVoiceDB.userTopic_xRef on userTopic_xRef.topicId = topic.topicId and userTopic_xRef.isActive = '1' and userTopic_xRef.isSubscribed = '1' group by topic.topicId, challenge  having count(challenge) >= " + constants.minNumberOfQuestionsToStartTest + " order by Topic desc";
            console.log('Topic Query --> ' + readTopicQuery);
            conn.query(readTopicQuery, function (err, rows, fields) {
              if (err) {
                console.log('DB Error: ', err);
                conn.destroy();
                throw err;
              }
              conn.destroy();

              // if(rows.length === 1){
              //   this.attributes['speechOutput'] = '';
              //   this.emitWithState('populateQuestions');
              // }

              //Check if topic user requested exists in the list
              for (var i = 0; i < rows[0].length; i++) {
                (i === 0) ? topicName += `<s>` + rows[0][i].name + ' </s> ,' : (rows[0][i].name === rows[0][i - 1].name) ? "" : topicName += `<s>` + rows[0][i].name + ' </s> ,'
                ///topicName += `<s>` + rows[i].name + ' </s> ,'
                //Get the similarity in DB version and user spoken verson.
                maxSimilarity = util.similar(topic, topicName);

                if ((rows[0][i].name.toLowerCase() === topic.toLowerCase()) ||
                  (clj_fuzzy.phonetics.soundex(topic) == clj_fuzzy.phonetics.soundex(rows[0][i].name)) &&
                  (maxSimilarity > constants.topicSimilarityAllowed)) {
                  topicFound = true;
                  pointerToThis.attributes['TopicId'] = rows[0][i].topicId;
                  console.log('Topic ID -> ' + pointerToThis.attributes['TopicId']);
                  pointerToThis.attributes['Topic'] = rows[0][i].name;
                  console.log('Topic Name -> ' + pointerToThis.attributes['Topic'] + ' Percent Match -> ' + maxSimilarity);
                  SelectedTopic = rows[0][i].name;

                  if (rows[0][i].num > constants.minNumberOfQuestionsToStartTest) {
                    (rows[0][i].challenge == "S") ? (availableChallengeLevel += `<s>Starter</s>`) : "";

                    (rows[0][i].challenge == "I") ? (availableChallengeLevel += `<s>Intermediate</s>`) : "";

                    (rows[0][i].challenge == "A") ? (availableChallengeLevel += `<s>Advanced</s>`) : "";

                    ChallengeLevelCount += 1;
                    currentChallengeLevel = rows[0][i].challenge;
                  }
                }
              }
              callback(null, availableChallengeLevel, topicFound);
            });
          },

          function (availableChallengeLevel, topicFound, callback) {
            //topicName += `:`;
            if (!topicFound) {
              console.log('Topic not found ');
              pointerToThis.attributes['TopicId'] = "";
              pointerToThis.attributes['Topic'] = "";
              pointerToThis.attributes['AvailableTopics'] = topicName;
              console.log("Topics at the end of topic intent ->" + pointerToThis.attributes['AvailableTopics']);
              //pointerToThis.emitWithState('TopicNotAvailable');
              speechOutput = 'No matches found! Did you mean <s> ' + topic + '?</s> Available Topics are : ' + topicName + ' say <s>open</s> and name of the  Topic';
              repromptSpeech = 'Available Topics are ' + topicName + ', the topic, say <s>open</s> and, - the name of the topic! ', 'You could also say exit to end';
            } else {

              speechOutput = 'Select a challenge Level for <s> ' + SelectedTopic + ' </s> Options are ' + availableChallengeLevel + ' Say <s> Select </s> and the Challenge level';
              repromptSpeech = 'Remember to say <s>Select</s> and the Challenge level, Options are ' + availableChallengeLevel;
             
            }
            callback(speechOutput, callback);
          },
        ],
        function (speechOutput, err) {
          //var speechOutput = options.SelectOption(topic);
          //TODO: BETA code 
          console.log('Completing Topic Intent');

          if (topicFound) {
            pointerToThis.handler.state = constants.states.QUESTIONANSWER;
            if (ChallengeLevelCount == 1) {
              pointerToThis.attributes['challengeLevelInd'] = currentChallengeLevel;
              pointerToThis.emitWithState('populateQuestions');
            }
          }
          VoiceLabs.track(pointerToThis.event.session, pointerToThis.event.request.intent.name, pointerToThis.event.request.intent.slots, null, (error, response) => {
            pointerToThis.emit(':ask', speechOutput, speechOutput);
          });

        }
      );