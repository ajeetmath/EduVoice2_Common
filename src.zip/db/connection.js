//var dbconfig = require('./dbconfig.js');
var mysql = require('mysql');
var data;
var constants = require('../constants/constants');

module.exports = {
	GetQuestions: function (topic, currentQuestionCount) {
		console.log(' connection:GetQuestions start');
		var db_access = {
			// host     : dbconfig.db.host,
			// user     : dbconfig.db.username,
			// password : dbconfig.db.password,
			// database : dbconfig.db.dbname,
			host: 'eduvoiceinstance.cduzgqaopwno.us-east-1.rds.amazonaws.com',
			user: 'windsorinfosys',
			password: 'Windsorinfosysatblr',
			database: 'EduVoiceDB',
			port: '3306'
		};

		console.log(' connection:GetQuestions calling DB');

		var conn = mysql.createConnection(db_access);
		conn.connect();

		//var currentQuestionCount = 20
		//var topic = "psycology";

		var queryString = "SELECT * FROM question where questionid > " + currentQuestionCount + " and topic ='" + topic + "' order by questionId ASC LIMIT " + constants.questionsToRead;
		console.log('Query ' + queryString);


		conn.query(queryString, function (err, rows, fields) {
			console.log(' connection:GetQuestions complete DB call');
			if (err) {
				console.log('DB Error: ', err);
				throw err;
			}

			data = rows;
			// for (var i in data) {
			// 	console.log('Question text ', data[i]);

			// }
			return data;
		});





		conn.end();
	}
};