var dbconfig = {};
dbconfig.db = {};

dbconfig.db.type = 'mysql';
dbconfig.db.charset = 'utf8';

dbconfig.db.username = 'windsorinfosys';
dbconfig.db.password = 'Windsorinfosysatblr';
dbconfig.db.host = 'eduvoiceinstance.cduzgqaopwno.us-east-1.rds.amazonaws.com';
dbconfig.db.port = '3306';
dbconfig.db.dbname = 'EduVoiceDB';

dbconfig.db.amznProfileURL = 'https://api.amazon.com/user/profile?access_token=';
module.exports = dbconfig;
