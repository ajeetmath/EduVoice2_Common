  //
  //
  // connection.query("SELECT * FROM questions", function(err, rows) {
  //         if (err) {
  //           console.log(err);
  //           callback(err, err);
  //         } else {
  //           rows.forEach(function(item) {
  //             console.log(JSON.stringify(item));
  //           });
  //           connection.end();
  //           callback(null, rows);
  //         }
  //       });
