class Onboarding {
    static getHandlers() {
        return {
            'NewSession': function () {
                // Check for User Data in Session Attributes
                console.log("onboardingStateHandlers : NewSession")

                //this.attributes['UserState'] = "NewSession";
                app.setSessionAttribute('UserState', constants.UserState.NewSession);
                this.attributes['IntentState'] = "NewSession";
                app.setSessionAttribute('IntentState', 'NewSession');

                var data = [];
                deviceId = 'this.event.context.System.device.deviceId';
                console.log('DeviceId -> ' + deviceId);

                var queryString = 'select userDeviceId, endUser.firstName, endUser.userId from EduVoiceDB.userDevices inner join endUser on endUser.userId = userDevices.endUserId where userDeviceId = "' + deviceId + '"';

                let rows;
                Database.execute(
                    database => database.query(queryString)
                        .then(r => {
                            rows = r;
                        })
                ).then(() => {
                    if (rows.length > 0) {
                        var UserId = rows[0].userId;
                        console.log('USer Id => ' + UserId);
                        console.log('USer Name => ' + rows[0].firstName);
                        app.setSessionAttribute('userName', rows[0].firstName);
                        //this.attributes['userName'] = rows[0].firstName;
                        //this.attributes['UserId'] = rows[0].userId
                        app.setSessionAttribute('UserId', rows[0].userId);
                        // speechOutput = ` Welcome Back <s>` + rows[0].firstName + `</s>. To Start Say <s>Open and the Topic name</s> or ` + constants.HelpPrompt;
                        // this.handler.state = constants.states.MAIN;
                        app.setSessionAttribute('UserState', constants.UserState.UserSelected);
                        // this.attributes['UserState'] = "UserSelected";

                        // this.attributes['speechOutput'] = ` Welcome Back ` + rows[0].firstName + `!. `;
                        app.setSessionAttribute('speechOutput', ` Welcome Back ` + rows[0].firstName + `!. `);
                        app.toIntent('TopicIntent');
                        //app.ask( speechOutput, ` To Start Say <s>Open and the Topic name</s> or ` + constants.HelpPrompt + constants.HowToUsePrompt);
                    } else {
                        console.log('Conform your Unic Pin');
                        app.ask(`<prosody rate="` + constants.speachSpeed + `"> To Link this Device, Read the Unique Pin from your <s>QuizMe.Guru account </s>  and Say <s>my Pin is and the pin</s> </prosody>` + constants.HelpPrompt + constants.HowToUsePrompt, `<prosody rate="` + constants.speachSpeed + `">Link this Device or ` + constants.HelpPrompt + constants.HowToUsePrompt + `</prosody>`);
                    }

                }).catch(err => {
                    console.log('DB Error in NewSession Request: ', err);
                    app.tell(constants.errorPrompt);
                });
            },

            'LinkDevice': function (pin) {
                // this.attributes['IntentState'] = "LinkDevice";
                app.setSessionAttribute('IntentState', 'LinkDevice');
                console.log("start LinkDevice");
                deviceId = 'this.event.context.System.device.deviceId';

                var pinFlag = false;
                var userData = [];
                var userId = app.getUserId();;
                // var pin = this.event.request.intent.slots.Pin.value;
                console.log('user unique pin -> ' + pin);

                var queryString = 'call SP_device_insert_alexa("' + pin + '","' + deviceId + '")';

                let rows;
                Database.execute(
                    database => database.query(queryString)
                        .then(r => {
                            rows = r;
                        })
                ).then(() => {
                    if (rows.length > 0) {
                        if (rows[0][0].errorcode == "-1001") {
                            speechOutput = "Device registered!, Start quiz by saying <s> Open </s> and the <s> Topic Name </s>";
                            repromptText = "You can start by saying <s> Open </s> and the <s> Topic Name </s>"
                            //   this.attributes['UserId'] = rows[0][0].userId;
                            app.setSessionAttribute('UserId', rows[0][0].userId);
                            //   this.handler.state = constants.states.MAIN;
                            //   this.attributes['UserState'] = "UserSelected";
                            app.setSessionAttribute('UserState', constants.UserState.UserSelected);
                        } else
                            if (rows[0][0].errorcode == "-1002") {
                                speechOutput = "Device registered with a different account, for help, please email to<s>Kumar@windsorinfosys.com</s> or " + constants.HelpPrompt;
                                repromptText = "Device registered with a different account or " + constants.HelpPrompt
                            }
                        if (rows[0][0].errorcode == "-1003") {
                            speechOutput = "Did not understand or Invalid Pin, say the pin again!";
                            repromptText = "Say <s> my Pin is</s> and the <s>pin</s> or " + constants.HelpPrompt;
                        }
                        if (rows[0][0].errorcode == "202") {
                            speechOutput = "Device registered! <s>" + rows[0][0].firstName + "</s> To start quiz, Say <s> Open </s> and the <s> Topic Name </s> ";
                            repromptText = "To start quiz, Say <s> Open </s> and the <s> Topic Name </s> ";
                            //   this.attributes['UserId'] = rows[0][0].userId;
                            app.setSessionAttribute('UserId', rows[0][0].userId);
                            //   this.handler.state = constants.states.MAIN;
                            //   this.attributes['UserState'] = "UserSelected";
                            app.setSessionAttribute('UserState', constants.UserState.UserSelected);
                        }
                    }
                    app.ask(speechOutput, repromptText);
                }).catch(err => {
                    console.log('DB Error in LinkDevice: ', err);
                    app.tell(constants.errorPrompt);
                });

            }
        }
    }
}
