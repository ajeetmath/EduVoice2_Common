const app = require('jovo-framework').Jovo;
var Alexa = require('alexa-sdk');
var mysql = require('mysql');
var Database = require('../db/dbwrapper');
var clj_fuzzy = require('clj-fuzzy');
var constants = require('../constants/constants');
var util = require('../inc/util');
var arrayFunctions = require('../inc/ArrayFunctions');
var help = require('../inc/help');
var RepeatText = '<s>Please Repeat!</s> ';
var skillExit = 'Thank you For Using QuizMe.';
var topicName = [];
var questionData = [];
var nextQuesIndex;
var answerText = [];
var challengLevelSlotValue = '';
// var mainStateHandlers = app.CreateStateHandler(constants.states.MAIN, {
//Database 
Database.execute = function (callback) {
    const database = new Database();
    return callback(database).then(
        result => database.close().then(() => result),
        err => database.close().then(() => {
            throw err;
        })
    );
};

class mainStateHandlers {

    static getHandlers() {
        return {

            'LAUNCH': function () {
                console.log('Launch intent');
                app.setSessionAttribute('IntentState', "LAUNCH");
                app.setSessionAttribute('state', constants.states.MAIN)
                app.setSessionAttribute('UserState', constants.UserState.UserSelected)
                app.setSessionAttribute('ChallengeLevelIntent', '')
                app.setSessionAttribute('Topic', '')
                app.toIntent('AMAZON.StartOverIntent');
            },

            'AMAZON.StartOverIntent': function () {
                app.setSessionAttribute('IntentState', "AMAZON.StartOverIntent");
                app.setSessionAttribute('state', constants.states.MAIN);
                app.setSessionAttribute('UserState', constants.UserState.UserSelected)
                app.setSessionAttribute('ChallengeLevelIntent', '');
                app.setSessionAttribute('Topic', '')
                app.ask('Hey! get topics by saying open topic');
            },

            // Say 'My name is ...'
            'NameIntent': function (name) {
                console.log('UserName -> ' + name);
                app.tell('Hey ! ' + name + ' How is it going?');
            },

            'ReadContent': function (txt) {
                console.log('Content -> ' + txt);
            },

            'TopicIntent': function (topic) {
                console.log("Starting mainStateHandler:TopicIntent");
                app.setSessionAttribute('IntentState', "TopicIntent");
                console.log("User requested Topic ->" + topic);
                var msg;
                console.log('USerstate -> ' + app.getSessionAttribute('UserState'))
                if (help.isValidContext(app.getSessionAttribute('IntentState'), app.getSessionAttribute('state'))) {
                    msg = help.isValidContext(app.getSessionAttribute('IntentState'), app.getSessionAttribute('state'));
                    console.log("TopicIntent isValidContext msg -> " + msg);
                    app.ask(msg, constants.HelpPrompt);
                }
                else {

                    // app.setSessionAttribute('Topic', topic);
                    var NewSession = false;
                    // var topic = app.getInput();
                    if (app.getSessionAttribute('IntentState') == "NewSession") {
                        NewSession = true;
                    }
                    var SelectedTopic = "";
                    var repromptSpeech = '';
                    var speechOutput = '';
                    var updatedIntent = app.getIntentName();
                    var slotToElicit;
                    var ChallengeLevelCount = 0;
                    var currentChallengeLevel = '';
                    // var userTopicPrompt = app.getInputs(topic);
                    // var topic = "";
                    var NewSessionFlow = false;
                    console.log("mainStateHandlers:TopicIntent start ")
                    var userTopicPrompt = "";

                    // if (app.getIntentName()) {
                    if (topic) {
                        userTopicPrompt = '%' + topic + '%';
                        //     topic = topic;
                        console.log("User topic  -> " + userTopicPrompt);
                    }
                    // } 
                    // else {
                    //     NewSessionFlow = true
                    // }

                    var availableChallengeLevel;
                    var topicFound = false;
                    var topicName = "";
                    var similarity = ""
                    var maxSimilarity = "";
                    var availableChallengeLevel = "";
                    var uID = 1063;
                    let rows;
                    // console.log("userTopicPrompt -> "+userTopicPrompt)
                    Database.execute(
                        // database => database.query("call SP_testTopics_alexa ('" + app.getSessionAttribute('UserId') + "','" + userTopicPrompt + "')")
                        database => database.query("call SP_testTopics_alexa (1063,'" + userTopicPrompt + "')")
                            .then(r => {
                                rows = r;
                            })
                    ).then(() => {
                        var multupleTopic;
                        console.log('Query String -> ' + "call SP_testTopics_alexa ('" + uID + "','" + userTopicPrompt + "')");
                        for (var i = 0; i < rows[0].length; i++) {
                            (i === 0) ? multupleTopic = false : (multupleTopic == true) ? multupleTopic = true : (rows[0][i].name === rows[0][i - 1].name) ? multupleTopic = false : multupleTopic = true;
                            (i === 0) ? topicName += `<s>` + rows[0][i].name + ' </s> ,' : (rows[0][i].name === rows[0][i - 1].name) ? "" : topicName += ` <s>` + rows[0][i].name + ' </s> ,';

                        }
                        console.log('multupleTopic ->' + multupleTopic);
                        console.log('topicName ->' + topicName)
                        if (multupleTopic && topic != "") {
                            app.getSessionAttribute('TopicId')
                            speechOutput = ' Multiple topics Found! ' + topicName + ', Say <s> Open and the Topic Name</s>';
                            repromptSpeech = ' Say <s> Open and the Topic Name</s>, Options are ' + topicName + constants.HelpPrompt;
                        } else if (multupleTopic && NewSession == true) {
                            speechOutput = app.getSessionAttribute('speechOutput') + ' Say <s> Open and the Topic Name</s>, Or Say Find topics ';
                            repromptSpeech = ' Say <s> Open and the Topic Name</s>, Options are ' + topicName;
                        } else if (multupleTopic && NewSession == false) {
                            speechOutput = 'Available Topics are ' + topicName + ' Say <s> Open and the Topic Name</s>';
                            repromptSpeech = ' Say <s> Open and the Topic Name</s>, Options are ' + topicName;
                        } else {
                            for (var i = 0; i < rows[0].length; i++) {
                                if ((rows[0][i].name.toString().toLowerCase() === topic.toString().toLowerCase()) ||
                                    (clj_fuzzy.phonetics.soundex(topic) == clj_fuzzy.phonetics.soundex(rows[0][i].name))) {
                                    maxSimilarity = util.similar(topic, rows[0][i].name);
                                    topicFound = true;
                                    app.setSessionAttribute('TopicId', rows[0][i].topicId);
                                    console.log('Topic ID -> ' + app.getSessionAttribute('TopicId'));
                                    app.setSessionAttribute('Topic', rows[0][i].name);
                                    console.log('Topic Name -> ' + app.getSessionAttribute('Topic') + ' Percent Match -> ' + maxSimilarity);
                                    SelectedTopic = rows[0][i].name;

                                    if (rows[0][i].challenge == "S" && rows[0][i].count >= constants.minNumberOfQuestionsToStartTest) {
                                        availableChallengeLevel += `<s>Starter</s>`;
                                        ChallengeLevelCount += 1;
                                        currentChallengeLevel = "S"
                                    }
                                    if (rows[0][i].challenge == "I" && rows[0][i].count >= constants.minNumberOfQuestionsToStartTest) {
                                        availableChallengeLevel += `<s>Intermediate</s>`;
                                        ChallengeLevelCount += 1;
                                        currentChallengeLevel = "I"
                                    }
                                    if (rows[0][i].challenge == "A" && rows[0][i].count >= constants.minNumberOfQuestionsToStartTest) {
                                        availableChallengeLevel += `<s>Advanced</s>`;
                                        ChallengeLevelCount += 1;
                                        currentChallengeLevel = "A"
                                    }
                                }
                            }
                            console.log('currentChallengeLevel -> ' + currentChallengeLevel);

                            if (!app.getSessionAttribute('Topic')) {
                                console.log('Topic not found ');
                                // app.setSessionAttribute('Topic', '');
                                app.setSessionAttribute('AvailableTopics', topicName);
                                console.log("Topics at the end of topic intent ->" + app.getSessionAttribute('AvailableTopics'));
                                speechOutput = 'No matches found for <s> ' + topic + '</s> Available Topics are : ' + topicName + ' say <s>open</s> and name of the  Topic';
                                repromptSpeech = 'Available Topics are <s>' + topicName + '</s>, say <s>open</s> and, topic name! ', 'You could also say exit to end';
                            } else {
                                console.log('SelectedTopic -> ' + SelectedTopic)
                                speechOutput = 'Available challenge Level ' + availableChallengeLevel + ' Say <s> Select </s> and the <s>Challenge level</s>';
                                repromptSpeech = ' Say <s> Select </s> and the <s>Challenge level</s>, Options are ' + availableChallengeLevel;
                                app.setSessionAttribute('UserState', constants.UserState.TopicNameSelected);
                                app.setSessionAttribute('state', constants.states.MAIN)
                                if (ChallengeLevelCount == 1) {
                                    app.setSessionAttribute('UserState', constants.UserState.ChallangeLevelSelected);
                                    // this.handler.state = constants.states.QUESTIONANSWER;
                                    app.setSessionAttribute('state', constants.states.QUESTIONANSWER);

                                    app.setSessionAttribute('challengeLevelInd', currentChallengeLevel);
                                    app.toIntent('populateQuestions')
                                }
                            }
                        }
                        console.log('Completing Topic Intent');

                        if (!topicFound || ChallengeLevelCount > 1 || multupleTopic == true) {
                            app.ask(speechOutput, repromptSpeech);
                        }
                    }).catch(err => {
                        console.log('DB Error: ', err);
                        app.tell(constants.errorPrompt);
                    });
                }
            },

            'ChallengeLevelIntent': function (challengeLevel) {

                app.setSessionAttribute('IntentState', 'ChallengeLevelIntent');
                var msg;
                if (help.isValidContext(app.getSessionAttribute('IntentState'), app.getSessionAttribute('state'))) {
                    msg = help.isValidContext(app.getSessionAttribute('IntentState'), app.getSessionAttribute('state'));
                    console.log("ChallengeLevelIntent isValidContext msg -> " + msg);
                    app.ask(msg, constants.HelpPrompt);
                }
                else {
                    // var challengeLevel;
                    console.log("questionAnswerHandlers:challengeLevelIntent start ");
                    //    slotValue = (app.getchallengeLevel() ? app.getchallengeLevel() : "")
                    var slotValue = challengeLevel;

                    if (slotValue === 'starter' || app.getSessionAttribute('challengeLevelInd') === 'S') {
                        challengeLevel = 'S';
                        app.setSessionAttribute('challengeLevelInd', challengeLevel);
                        slotValue = 'starter';
                    } else if (slotValue === 'intermediate' || app.getSessionAttribute('challengeLevelInd') === 'I') {
                        challengeLevel = 'I';
                        app.setSessionAttribute('challengeLevelInd', challengeLevel);
                        slotValue = 'intermediate';
                    } else if (slotValue === 'advanced' || app.getSessionAttribute('challengeLevelInd') === 'A') {
                        challengeLevel = 'A';
                        app.setSessionAttribute('challengeLevelInd', challengeLevel);
                        slotValue = 'advanced';
                    } else {
                        challengeLevel = 'S';
                        slotValue = 'starter';
                        app.setSessionAttribute('challengeLevelInd', challengeLevel);
                    }
                    app.setSessionAttribute('UserState', constants.UserState.ChallangeLevelSelected);
                    challengLevelSlotValue = slotValue;
                    // this.handler.state = constants.states.QUESTIONANSWER;
                    app.setSessionAttribute('state', constants.states.QUESTIONANSWER)
                    app.toIntent('populateQuestions');
                }
            },

            'populateQuestions': function () {

                app.setSessionAttribute('IntentState', 'populateQuestions');
                var ansData = [];
                var randomQuestions = [];
                var data;
                console.log('populateQuestions handler : Populate Questions for ' + app.getSessionAttribute('Topic'));
                var topic = app.getSessionAttribute('Topic');
                var testTopic = app.getSessionAttribute('Topic');
                var qId = [];
                var speechOutput = '';
                //If topic selected is not available return a friendly message.

                //Printing the event request
                //Setting null to the session attribute variables
                app.setSessionAttribute('correctAnsweredQuestionId', '');
                app.setSessionAttribute('wrongAnsweredQuestionId', '');
                //First time load set questionCount = 0
                //Get questions for the sleected Topic
                app.setSessionAttribute('TestIndex', 0);
                app.setSessionAttribute('currentQuestionIndex', 0)
                var count = 0;

                var queryString = 'call SP_accessQuestion_alexa("' + app.getSessionAttribute('TopicId') + '", "' + app.getSessionAttribute('challengeLevelInd') + '","0","' + constants.questionsToRead + '")';

                let rows;
                Database.execute(
                    database => database.query(queryString)
                        .then(r => {
                            rows = r;
                        })
                ).then(() => {

                    data = rows[0];
                    for (var i in data) {
                        qId[i] = data[i].questionId;
                    }
                    var maxQuestionID = arrayFunctions.maxAaaryValue(qId);
                    console.log("Max Question Id-> " + maxQuestionID);
                    console.log("Qiestion Id " + qId);
                    //Add o session attribute
                    app.setSessionAttribute('maxQuestionID', maxQuestionID);
                    questionData = arrayFunctions.shuffleArray(data);
                    app.setSessionAttribute('questions', questionData);

                    //Reading the first Question from the multi dimentional array.

                    //1 Read the questions
                    if (app.getSessionAttribute('twoPlayersQuiz')) {
                        speechOutput = `Starting Quiz for <s>` + testTopic + ` </s>  Question for <s>player 1</s>. <prosody rate="` + constants.speachSpeed + `">` + questionData[0].text + ', <s> Options are </s>';
                    } else {
                        speechOutput = `Starting  Quiz for <s>` + testTopic + ` </s>  Question, <prosody rate="` + constants.speachSpeed + `">` + questionData[0].text + ', <s> Options are </s>';
                    }

                    //1 Read the options
                    //Read the option and output them
                    var rowData = JSON.parse("[" + questionData[0].options + "]");
                    var opt = " ";
                    for (var key = 0; key < rowData.length; key++) {
                        var dt = rowData[key];
                        for (var i in dt) {
                            if (dt[i] != "") {
                                speechOutput = speechOutput + ' - ' + (`<s>` + i + `</s>` + ' - ' + dt[i] + ',<break time="' + constants.pauseTime + '"/> ');
                                opt = opt + i + `, - `;
                                answerText[i] = dt[i];
                            }
                        }
                    }
                    speechOutput += `</prosody>`;
                    console.log('Questoin -> ' + speechOutput)

                    app.setSessionAttribute('score', 0)
                    app.setSessionAttribute('correctAnswerText', questionData[0].answer)
                    app.setSessionAttribute('questionId', questionData[0].questionId)
                    console.log("Qid - > " + app.getSessionAttribute('questionId'));
                    app.setSessionAttribute('UserState', constants.UserState.QuestionsRead)
                    app.setSessionAttribute('state', constants.states.QUESTIONANSWER);
                    // VoiceLabs.track(this.event.session, 'populateQuestions', null, null, (error, response) => {
                    app.ask(speechOutput,  `<prosody rate="` + constants.speachSpeed + `">` + `To answer use one of these options ` + opt + `</prosody>`);
                    // });
                }).catch(err => {
                    console.log('DB Error in NewSession Request: ', err);
                    app.tell(constants.errorPrompt);
                });
            },

            'AnswerIntent': function (answer) {


                //TODO : ****************    Ooption needs to be provided to seek th explaination aftere correct/incorrect option before moving tho the next question.
                app.setSessionAttribute('IntentState', 'AnswerIntent')
                var msg;
                if (help.isValidContext(app.getSessionAttribute('IntentState'), app.getSessionAttribute('state'))) {
                    msg = help.isValidContext(app.getSessionAttribute('IntentState'), app.getSessionAttribute('state'));
                    console.log("AnswerIntent isValidContext msg -> " + msg);
                    app.ask(msg, constants.HelpPrompt);
                }
                else {
    
                    console.log("start handleAnswers");
                    console.log("User Answer : " + answer);
                    var speechOutput = '';
                    //In case mo test in progress return a freindly error message. Transfer to NoTestInProgress function
                    if (!questionData) {
                        app.toIntent('NoTestInProgress');
                    } else {
                        if (!answer || answer === undefined) {
                            app.ask('answer the question by saying - the answer is A, - B, - C, - D or E.');
                        } else {
                            var quslen = app.getSessionAttribute('questions').length;
                            // this.attributes['firstPlayerScore'] = 0;
                            // this.attributes['secondPlayerScore'] = 0;

                            //	if (answer === "a" || answer === "b" || answer === "c" || answer === "d" || answer === "e") {
                            var correctAnswerFlag = false;

                            answer = answer.toString().toLowerCase();

                            //Sometime alexa returns a . in addition to the option. below is to address it
                            answer = answer.substr(0, 1);
                            app.setSessionAttribute('currentQuestionIndex', app.getSessionAttribute('currentQuestionIndex') + 1);
                            app.setSessionAttribute('TestIndex', app.getSessionAttribute('TestIndex') + 1);

                            if (app.getSessionAttribute('correctAnswerText').toString().toLowerCase() === answer.toString().toLowerCase()) {
                                speechOutput = " correct answer ";
                                correctAnswerFlag = true;
                                //storing this score value in to database so, keeping as it is. later can be removed.
                                app.setSessionAttribute('score', app.getSessionAttribute('score') + 1);

                                console.log("Correct Answer ");
                                //QuestionId which are answered correct
                                app.setSessionAttribute('correctAnsweredQuestionId', app.getSessionAttribute('correctAnsweredQuestionId') + app.getSessionAttribute('questionId') + ' ');
                                console.log("Correct Answered QuestionId --> " + app.getSessionAttribute('correctAnsweredQuestionId'));
                                //TODO Read questions for the Selected Values
                                console.log("Total Question length : " + quslen + ' Test index -> ' + app.getSessionAttribute('TestIndex'));
                                app.setSessionAttribute('speechOutput', speechOutput);
                            } else {
                                speechOutput = " - ,Incorrect answer, the correct answer is, " + app.getSessionAttribute('correctAnswerText') + " - <s>" + answerText[app.getSessionAttribute('correctAnswerText')] + "</s>,  ";
                                //QuestionId which are answered wrong
                                app.setSessionAttribute('wrongAnsweredQuestionId', app.getSessionAttribute('wrongAnsweredQuestionId') + app.getSessionAttribute('questionId') + ' ');
                                //Ask for explaination
                                app.setSessionAttribute('speechOutput', speechOutput);

                                //VoiceLabs.track(this.event.session, null, null, null, (error, response) => {
                                // app.ask( speechOutput, ', To Explain, try saying, - Explain the Answer or say next question - to continue quiz ');
                                //});
                            }
                            console.log('Current question index -> ' + app.getSessionAttribute('currentQuestionIndex'));

                            if (app.getSessionAttribute('twoPlayersQuiz')) {

                                if (app.getSessionAttribute('currentQuestionIndex') % 2 === 0) {
                                    if (correctAnswerFlag) {
                                        firstPlayerScore += 1;
                                    }
                                    console.log("Player 2's questionIndex ->" + app.getSessionAttribute('currentQuestionIndex'))
                                    console.log("Plater 2's score ->" + app.getSessionAttribute('secondPlayerScore'));
                                    app.toIntent('SecondPlayer');
                                } else {
                                    if (correctAnswerFlag) {
                                        secondPlayerScore += 1;
                                    }
                                    console.log("Player 1's questionIndex ->" + app.getSessionAttribute('currentQuestionIndex'))
                                    console.log("Plater 1's score ->" + app.getSessionAttribute('firstPlayerScore'));
                                    app.toIntent('FirstPlayer');
                                }
                            } else {

                                if (app.getSessionAttribute('currentQuestionIndex') <= quslen) {
                                    app.toIntent('ContinueGetNextQuestion');
                                    //		}
                                    //		 else {
                                    // this.attributes['speechOutput'] = " - ";
                                    // app.toIntent('endOfTest');
                                    //		}
                                } else {
                                    app.setSessionAttribute('speechOutput', app.getSessionAttribute('speechOutput') + " End of this quiz ");
                                    app.toIntent('endOfTest');
                                }
                            }
                        }
                    }
                }
            },

            'ContinueGetNextQuestion': function () {

                nextQuesIndex = app.getSessionAttribute('currentQuestionIndex');
                questionData = app.getSessionAttribute('questions');
                var completedCount = app.getSessionAttribute('TestIndex');
                var speechOutput = '';
                //if the compleated question count is equal to configured count, exit test 
                console.log('completedCount -> ' + completedCount)
                if (completedCount >= constants.TestSize) {
                    console.log('end');
                    app.toIntent('endOfTest');
                } else {

                    speechOutput = ` -  <prosody rate="` + constants.speachSpeed + `">` + questionData[nextQuesIndex].text + '. <s> Options are </s> ';
                    //Assigning the next question Options 
                    var rowData = JSON.parse("[" + questionData[nextQuesIndex].options + "]");
                    for (var key = 0; key < rowData.length; key++) {
                        var dt = rowData[key];
                        for (var i in dt) {
                            if (dt[i] != "") {
                                speechOutput = speechOutput + ' - ' + (`<s>` + i + `</s>` + ' - ' + dt[i] + ',<break time="' + constants.pauseTime + '"/> ');
                                answerText[i] = dt[i];
                            }
                        }
                    }
                    speechOutput += `</prosody>`;
                    console.log('Next Question is : ' + speechOutput)

                    /////reset he current index to zer
                    app.setSessionAttribute('currentQuestionIndex', nextQuesIndex);
                    //populate the answer for the first row in the questions array
                    app.setSessionAttribute('correctAnswerText', questionData[nextQuesIndex].answer);
                    app.setSessionAttribute('questionId', questionData[nextQuesIndex].questionId);
                    //incrementing the testIndex by one
                    app.setSessionAttribute('UserState', constants.UserState.QuestionsRead)
                    app.setSessionAttribute('state', constants.states.QUESTIONANSWER);
                    // VoiceLabs.track(this.event.session, 'ContinueGetNextQuestion', null, null, (error, response) => {
                    app.ask(app.getSessionAttribute('speechOutput') + ` Next Question ` + speechOutput, " Repeating the same question - " + speechOutput + " Say - the answer is <s>A</s>  <s> B </s> <s> C</s>  <s> D</s>  or <s> E</s>   or say Next question to skip this question.");
                    // });
                }
            },

            'endOfTest': function () {

                app.setSessionAttribute('IntentState', 'endOfTest');
                app.setSessionAttribute('UserState', constants.UserState.EndOfTest);
                console.log('Starting endOfTest ');
                app.setSessionAttribute('questions', '');
                var speechOutput = '';
                var questionsTaken = (app.getSessionAttribute('TestIndex')) ? app.getSessionAttribute('TestIndex') : 0;
                var questionsTakenBy2Players = (questionsTaken > 1) ? questionsTakenBy2Players = questionsTaken / 2 : 0;

                var topicId = (app.getSessionAttribute('TopicId')) ? app.getSessionAttribute('TopicId') : 0;
                var correctQuestionId = (app.getSessionAttribute('correctAnsweredQuestionId')) ? app.getSessionAttribute('correctAnsweredQuestionId') : 0;
                var wrongQuestionId = (app.getSessionAttribute('wrongAnsweredQuestionId')) ? app.getSessionAttribute('wrongAnsweredQuestionId') : 0;
                var userId = app.getUserId();
                // var sessionId = app.getsessionId();
                var sessionId = 'app.getsessionId()';
                var date = new Date();
                var noOfCorrectAnswers = (app.getSessionAttribute('score')) ? app.getSessionAttribute('score') : 0;
                var queryString = 'insert into EduVoiceDB.testResult (userId, topicId, questionsTaken, correctAnswer, challengeHighCountQuestions, challengeHighCountCorrectAns, challengeIntermediateCountQuestions, challengeIntermediateCountCorrectAns, challengeStarterCountQuestions, challengeStarterCountCorrectAns, correctQuestionId, wrongQuestionId, createdDate, sessionId) values ("' + userId + '",' + topicId + ',' + questionsTaken + ',' + noOfCorrectAnswers + ',2,3,4,5,4,2,"' + correctQuestionId + '","' + wrongQuestionId + '","' + date.getFullYear() + '/' + date.getMonth() + '/' + date.getDate() + '","' + sessionId + '")';
                console.log('Query -> ' + queryString)
                console.log('correct questions ID -> ' + correctQuestionId);

                let rows;
                Database.execute(
                    database => database.query(queryString)
                        .then(r => {
                            rows = r;
                        })
                ).then(() => {
                    console.log('second function');
                    if (constants.TestSize != questionsTaken) {
                        speechOutput = app.getSessionAttribute('speechOutput') + " Quiz Ended  ";
                    } else {
                        speechOutput = app.getSessionAttribute('speechOutput');
                    }
                    console.log('speechOutput ->' + speechOutput);
                    //Reset so that we dont increase the data
                    //speechOutput = speechOutput + "Your total score is " + noOfCorrectAnswers + " - out of - " + questionsTaken + ",  ";
                    if (app.getSessionAttribute('twoPlayersQuiz')) {
                        speechOutput = speechOutput + "Player 1's score is " + firstPlayerScore + " - out of - " + questionsTakenBy2Players + ", and player 2's score is " + secondPlayerScore + " - out of - " + questionsTakenBy2Players + " ";
                    } else {
                        speechOutput = speechOutput + "Your total score is " + noOfCorrectAnswers + " - out of - " + questionsTaken + ",  ";
                    }
                    console.log("Your total score is " + app.getSessionAttribute('score'));
                    // this.handler.state = constants.states.MAIN;
                    app.setSessionAttribute('state', constants.states.MAIN)
                    // VoiceLabs.track(this.event.session, 'endOfTest', null, null, (error, response) => {
                    app.tell(speechOutput + skillExit);
                    // });
                }).catch(err => {
                    console.log('DB Error: ', err);
                    app.tell(constants.errorPrompt);
                });
            },

            'RepeatQuestion': function () {
                console.log("start RepeatQuestion");
                var speechOutput = '';
                var currentQuestionIndex = app.getSessionAttribute('currentQuestionIndex');
                app.setSessionAttribute('IntentState', 'RepeatQuestion');
                var msg;
                if (help.isValidContext(app.getSessionAttribute('IntentState'), app.getSessionAttribute('state'))) {
                    msg = help.isValidContext(app.getSessionAttribute('IntentState'), app.getSessionAttribute('state'));
                    console.log("RepeatQuestion isValidContext msg -> " + msg);
                    app.ask(msg, constants.HelpPrompt);
                }
                else {
                    //Since repeating th question
                    //It will repease the question
                    app.setSessionAttribute('UserState', constants.UserState.QuestionsRead)
                    app.setSessionAttribute('state', constants.states.QUESTIONANSWER);
                    speechOutput = "Repeating the question  - " + questionData[currentQuestionIndex].text;
                    // VoiceLabs.track(this.event.session, 'RepeatQuestion', null, null, (error, response) => {
                    app.ask(speechOutput, speechOutput + " , - to answer to this question try saying the answer is a, - b, - c, or - d. Or to skip this question say Next question ");
                }
            },

            'RepeatOptions': function () {
                console.log("start RepeatOptions");
                var speechOutput = '';
                var currentQuestionIndex = app.getSessionAttribute('currentQuestionIndex');
                app.setSessionAttribute('IntentState', 'RepeatOptions');
                var msg;
                if (help.isValidContext(app.getSessionAttribute('IntentState'), app.getSessionAttribute('state'))) {
                    msg = help.isValidContext(app.getSessionAttribute('IntentState'), app.getSessionAttribute('state'));
                    console.log("RepeatOptions isValidContext msg -> " + msg);
                    app.ask(msg, constants.HelpPrompt);
                }
                else {

                    //Repeating hte options 
                    //It will repease the options
                    var options = JSON.parse("[" + questionData[currentQuestionIndex].options + "]");
                    speechOutput = 'Repeating the options  ';

                    for (var key = 0; key < options.length; key++) {
                        var dt = options[key];
                        for (var i in dt) {
                            speechOutput = speechOutput + (i + ' - ' + dt[i] + ', ');
                        }
                    }
                    console.log('Repeating oprtions' + speechOutput);
                    app.setSessionAttribute('UserState', constants.UserState.QuestionsRead)
                    app.setSessionAttribute('state', constants.states.QUESTIONANSWER);
                    // VoiceLabs.track(this.event.session, 'RepeatOptions', null, null, (error, response) => {
                    app.ask(speechOutput, speechOutput + " , - to answer to this question try saying the answer is a, - b, - c, or - d. Or to skip this quesrion say Next question ");
                    // });
                }
            },

            'ExplainIntent': function () {

                console.log('Starting ExplainIntent ');
                var speechOutput = '';
                var explainSpeech = '';
                var currentQuestionIndex = app.getSessionAttribute('currentQuestionIndex');
                app.setSessionAttribute('IntentState', 'ExplainIntent');
                var msg;
                if (help.isValidContext(app.getSessionAttribute('IntentState'), app.getSessionAttribute('state'))) {
                    msg = help.isValidContext(app.getSessionAttribute('IntentState'), app.getSessionAttribute('state'));
                    console.log("RepeatOptions isValidContext msg -> " + msg);
                    app.ask(msg, constants.HelpPrompt);
                }
                else {

                    speechOutput = "Explaination for this answer is <s> ,  " + questionData[currentQuestionIndex].explain + " </s> ";
                    console.log('Explaination read-> ' + questionData[currentQuestionIndex].explain);
                    app.setSessionAttribute('score', app.getSessionAttribute('score') + 0);
                    explainSpeech = speechOutput + " The answer for this question is - " + app.getSessionAttribute('correctAnswerText') + " - " + answerText[app.getSessionAttribute('correctAnswerText')] + " - ";
                    console.log('explainSpeech -> ' + explainSpeech);
                    app.setSessionAttribute('speechOutput', explainSpeech);
                    app.setSessionAttribute('currentQuestionIndex', app.getSessionAttribute('currentQuestionIndex') + 1);
                    app.setSessionAttribute('state', constants.states.QUESTIONANSWER);
                    app.setSessionAttribute('TestIndex', app.getSessionAttribute('TestIndex') + 1);
                    //TODO verify the logic
                    if (app.getSessionAttribute('currentQuestionIndex') <= app.getSessionAttribute('questions').length) {
                        app.toIntent('ContinueGetNextQuestion');
                        // } else {
                        // 	this.attributes['speechOutput'] = " - ";
                        // 	app.toIntent('endOfTest');
                        // }
                    } else {
                        app.setSessionAttribute('speechOutput', app.getSessionAttribute('speechOutput') + " No more questions on theis topic. - ");
                        app.toIntent('endOfTest');
                    }
                }
            },

            'CallNextQuestion': function () {
                app.getSessionAttribute('currentQuestionIndex')

                console.log('Starting CallNextQuestion');
                app.setSessionAttribute('IntentState', 'CallNextQuestion');
                var msg;
                if (help.isValidContext(app.getSessionAttribute('IntentState'), app.getSessionAttribute('state'))) {
                    msg = help.isValidContext(app.getSessionAttribute('IntentState'), app.getSessionAttribute('state'));
                    console.log("CallNextQuestion isValidContext msg -> " + msg);
                    app.ask(msg, constants.HelpPrompt);
                }
                else {
                    //skipping the questions for the next question or requested after the explaination
                    if (app.getSessionAttribute('currentQuestionIndex') >= constants.questionsToRead) {
                        app.setSessionAttribute('currentQuestionIndex', 0);
                    } else {
                        app.setSessionAttribute('score', app.getSessionAttribute('score') ? app.getSessionAttribute('score') : 0 + 0);
                        // this.attributes['score'] = this.attributes['score'] ? this.attributes['score'] : 0 + 0;
                        console.log('CALL NEXT QUESTION');
                        console.log('skipping the question' + app.getSessionAttribute('currentQuestionIndex'));
                        app.setSessionAttribute('currentQuestionIndex', app.getSessionAttribute('currentQuestionIndex') + 1);
                        app.setSessionAttribute('TestIndex', app.getSessionAttribute('TestIndex') + 1);
                        app.setSessionAttribute('state', constants.states.QUESTIONANSWER);
                        app.setSessionAttribute('speechOutput', '');
                    }

                    if (app.getSessionAttribute('twoPlayersQuiz')) {
                        if (app.getSessionAttribute('currentQuestionIndex') % 2 === 0) {
                            app.toIntent('SecondPlayer');
                        } else {
                            app.toIntent('FirstPlayer');
                        }
                    } else {
                        app.toIntent('ContinueGetNextQuestion');
                    }
                }
            },

            'CatchAllSlot': function (catchallslot) {

                console.log('CatchAllSlot Intent');
                app.setSessionAttribute('IntentState', "CatchAllSlot");
                if (help.isValidContext(app.getSessionAttribute('IntentState'), app.getSessionAttribute('state'))) {
                    msg = help.isValidContext(app.getSessionAttribute('IntentState'), app.getSessionAttribute('state'));
                    console.log("CatchAllSlot isValidContext msg -> " + msg);
                    app.ask(msg, constants.HelpPrompt);
                }
                else {
                    //things to do
                    app.ask(RepeatText + "if you dont know what to say, get help by saying help me.", " Say Exit to end the session");
                }
            },


            'AMAZON.StopIntent': function () {
                console.log("Starting mainStateHandler:StopIntent");
                // State Automatically Saved with :tell
                // VoiceLabs.track(this.event.session, "AMAZON.StopIntent", null, null, (error, response) => {
                app.tell(constants.exitMessage);
                // });
            },

            'AMAZON.CancelIntent': function () {
                console.log("Starting mainStateHandler:CancelIntent");
                // State Automatically Saved with :tell
                // VoiceLabs.track(this.event.session, "AMAZON.CancelIntent", null, null, (error, response) => {
                app.tell(constants.exitMessage);
                // });
            },

            'SessionEndedRequest': function () {
                // Force State Save When User Times Out
                console.log("Starting mainStateHandler:SessionEndedRequest");
                // VoiceLabs.track(this.event.session, "SessionEndedRequest", null, null, (error, response) => {
                //this.emit(':saveState', true);
                app.tell(constants.exitMessage);
                // });
            },

            'AMAZON.HelpIntent': function () {
                console.log('AMAZON.HelpIntent')
                var txt = help.GetContexBasedHelp(app.getSessionAttribute('state'), app.getSessionAttribute('UserState'));
                console.log('Help me text -> '+txt)
                console.log('User State-> ' + app.getSessionAttribute('UserState'))
                console.log('Quiz State-> ' + app.getSessionAttribute('state'))
                // VoiceLabs.track(this.event.session, "mainStateHandlers:AMAZON.HelpIntent", null, null, (error, response) => {
                app.ask(txt, constants.HelpPrompt);
                // });
            },

            'HowToUse': function () {
                // VoiceLabs.track(this.event.session, "mainStateHandlers:HowToUse", null, null, (error, response) => {
                app.ask(help.GetHowToUse("_MAIN", null), "Say <s>Help me!</s> to repeat");
                // });
            },

            'Unhandled': function () {
                console.log("Starting Unhandled");
                var txt = help.ProcessUnHandledRequest(app.getSessionAttribute('UserState'));
                console.log("Unhandled txt -> " + txt);
                app.ask(txt, constants.HelpPrompt);

            },

            'AMAZON.PauseIntent': function () {
                console.log("Starting AMAZON.PauseIntent");
                // VoiceLabs.track(this.event.session, "questionAnswerHandlers:PauseIntent", null, null, (error, response) => {
                app.ask('Ok!', "Say <s> Wait!</s> for more time");
                // });
            },

            'DontKnowIntent': function () {
                app.setSessionAttribute('IntentState', 'DontKnowIntent');
                console.log("Starting DontKnowIntent");
                if (app.getSessionAttribute('IntentState') === "populateQuestions" || app.getSessionAttribute('IntentState') === "getNextQuestion") {
                    // VoiceLabs.track(this.event.session, "questionAnswerHandlers:DontKnowIntent", null, null, (error, response) => {
                    app.ask('Sorry! did not get you, answer the question by saying - the answer is A, - B, - C, - D or E.');
                    // });
                } else {
                    // VoiceLabs.track(this.event.session, "DontKnowIntent", null, null, (error, response) => {
                    app.ask(RepeatText + "if you dont know what to say, get help by saying help me.", " Say Exit to end the session");
                    // });
                }
            }
        }
    }
};
module.exports = mainStateHandlers;