var arrayFunctions = require('../inc/ArrayFunctions');

module.exports = {
  handleOption : function() {
    return null;
  },
  SelectOption : function(topic) {
    var options = [" Quiz Me " ," Teach Me "];
    var optionString =  arrayFunctions.ArrayToString(options);
    var	speechOutput = "okay, your options for "+ topic +" are " + optionString + "  try saying , - " + optionString;
    return speechOutput;
  }
};
