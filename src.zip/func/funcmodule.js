class FuncModule {
    constructor(config) {
    }
    
    GetTopic() {
        return new Promise((resolve, reject) => {
            (err => {
                if (err)
                    return reject(err);
                resolve();
            });
        });
    }
};



module.exports = FuncModule;
