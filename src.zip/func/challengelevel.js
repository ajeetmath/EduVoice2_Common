var arrayFunctions = require('../inc/ArrayFunctions');

module.exports = {
  handlechallengeLevel : function() {
    return null;
  },
  challengeLevel : function() {
    var challenges =  ["Starter", "Intermediate","Advanced"];
    return arrayFunctions.ArrayToString(challenges);
  }

};
