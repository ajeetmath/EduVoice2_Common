var arrayFunctions = require('../inc/ArrayFunctions');
var dbconfig = require('../db/dbconfig.js');
var dbconn = require('../db/connection');
var mysql = require('mysql');
var async = require('async');

var QUIZ_LENGTH = 5;

module.exports = {
  handleAnswerRequest: function () {
    return null;
  },

  loadQuestions: function (topic, currentQuestionCount) {
    var questions = dbconn.GetQuestions(topic, currentQuestionCount);
    //var questions = [["1","Which is the capital city of India ? - Options are a - New Delhi, b - Chennai , c- pune, d - Mumbai","a"],	["2","Which is the capital city of Karnataka ? - Options are a - New Delhi, b - Chennai , c- pune, d - Bangalore","d"]];
    console.log("randomize questions");
    questionData = arrayFunctions.shuffleArray(questions);
    //console.log("questionData " + arrayFunctions.printObject(questionData));
    return questionData;
  },

};