var arrayFunctions = require('../inc/ArrayFunctions');

module.exports = {
    OpenTopic : function() {
    return null;
  },

  handleTopics :  function() {
    var topics = ["Science", "Social"];
    var topicsString =  arrayFunctions.ArrayToString(topics);
  	var	speechOutput = "Topics available are " + topicsString + " - try saying open, - " + topicsString + " - and topic";
  	return speechOutput;
  }
};
