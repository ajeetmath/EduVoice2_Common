var constants = Object.freeze({
  appId: 'amzn1.ask.skill.87a20301-9dbf-4bd9-ae4c-10f330e1dc03',
  dynamoDBTableName: 'User',
  questionsToRead: 10, //this should be less than or equal to TestSize
  minNumberOfQuestionsToStartTest: 10, // this determines if the test can be used. should be greater than or equal to TestSize value
  TestSize: 5,
  pauseTime: '0.2s',
  speachSpeed: 'medium',
  topicSimilarityAllowed: 50, //this is the percentage value for percentage of confidance on text match
  // Skill States
  VoiceLabsCode:'7266f010-6884-11a7-11ce-02f814b60257',
  states: {
    ONBOARDING: '',
    MAIN: '_MAIN',
    QUESTIONANSWER: '_QUESTIONANSWER'
  },

  exitMessage: ' <prosody rate="medium">Good Bye!</prosody> ',
  errorPrompt : ' <prosody rate="medium"> Sorry, there was an issue with the Skill, please try again Later. </prosody> ',
  HowToUsePrompt : ' <prosody rate="medium"> Say <s>How to Use</s>  or, <s>What are my options!</s> </prosody> ',
  HelpPrompt : ' Say <s>Help Me!</s> ',
  TopicPromptTxt : ' Say <s> Open and the Topic Name</s> Or, <s> Find, and the name of the Topic!</s> ',
  UserState: {
    NewSession: 'NewSession',
    UserSelected: 'UserSelected',
    TopicNameSelected: 'TopicNameSelected',
    ChallangeLevelSelected: 'ChallangeLevelSelected',
    QuestionsRead :'QuestionsRead' ,
    EndOfTest:'EndOfTest'
  }

});

module.exports = constants;