'use strict';
var Alexa = require('alexa-sdk');
const app = require('jovo-framework').Jovo;
var mysql = require('mysql');

// var speech = "<speak>Welcome to the sand box. " + "<audio src='https://s3.amazonaws.com/sounds226/boom.mp3'/>" + "</speak>";
var handlers = require('./handlers/mainHandler').getHandlers();

exports.handler = function (event, context, callback) {
    app.handleRequest(event, callback, handlers);   
    app.execute();
    //Event
     var ar = [];
     var events = JSON.stringify(event);
     for (var i = 0; i < events.length; i++) {
         ar += events[i];
     }
     console.log("Event request ->" + ar);
};

// const handlers = {
//     // Say 'Open Jovo'
    
// };
