'use strict';

// =================================================================================
// App Configuration
// =================================================================================

const app = require('jovo-framework').Jovo;



var  speech = "<speak>Welcome to the sand box. " + "<audio src='https://s3.amazonaws.com/sounds226/boom.mp3'/>" + "</speak>";

exports.handler = function(event, context, callback) {
    app.handleRequest(event, callback, handlers);
    app.execute();
};


// =================================================================================
// App Logic
// =================================================================================

// const handlers = {

//     'LAUNCH': function() {
//         app.toIntent('NameIntent');
//     },

//     'HelloWorldIntent': function() {
        
//         app.tell(speech);
//     },
    
//     'NameIntent':function(){
//         app.ask(speech);
//     },
// };

const handlers = {
    // Say 'Open Jovo'
   'LAUNCH': function() {
    console.log('Launch intent');
       app.ask('Hey! What\'s your name?', 'Please tell me your name.');
   },
   // Say 'My name is ...'
   'NameIntent': function(name) {
       console.log('UserName -> '+name);
       app.tell('Hey ' + name + '! How is it going?');
   },
};
